from django.apps import AppConfig


class UserDataConfig(AppConfig):
    name = 'user_data'
